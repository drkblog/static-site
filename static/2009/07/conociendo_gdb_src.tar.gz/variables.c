#include <stdio.h>
#include <string.h>

struct rec {
  char nombre[30];
  unsigned int edad;
  char sexo;
} rec;

int main(int argc, char ** argv) {
  struct rec registro;
  int entero = 4433;
  char * str = NULL;
  char * texto = "Un texto.";
  char caracter = 'G';

  printf("Inicio\n");
  registro.edad = 20;
  registro.sexo = 'M';

  printf("Entero = %d\n", entero);
  printf("Caracter = %c\n", caracter);

  printf("Texto = %s\n", texto);
  printf("STR = %s\n", str);

  printf("FIN\n");

  return 0;
}

