#include <stdio.h>
#include <string.h>

void nivel_1(int * c, char * str);
void nivel_2(int * c, char * str);
void nivel_3(int * c, char * str);
void nivel_4(int * c, char * str);

int main(int argc, char ** argv) {

  char cadena[5];
  int longitud = 0;

  printf("Inicio\n");

  nivel_1(&longitud, cadena);

  printf("Resultado [%s]\n", cadena);

  printf("FIN\n");

  return 0;
}

void nivel_1(int * c, char * str) {

  str[(*c)++]='1';
  nivel_2(c, str);
}


void nivel_2(int * c, char * str) {

  str[(*c)++]='2';
  nivel_3(c, str);
}

void nivel_3(int * c, char * str) {

  float dummy = 3.141592f;

  str[(*c)++]='3';
  nivel_4(c, str);
}

void nivel_4(int * c, char * str) {

  str[(*c)++]='4';
  str[(*c)]=0;

  str[65535] = 123;

}
