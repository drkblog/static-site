#include <stdio.h>
#include <string.h>

void unNivel(int c, char * str);

int main(int argc, char ** argv) {

  printf("Paso 1\n");

  unNivel(5, "1234567890");

  printf("Paso 2\n");

  return 0;
}

void unNivel(int c, char * str) {

  char * duplicado;

  if (c >= strlen(str))
    return;

  duplicado = strdup(str);
  duplicado[c] = 0;
  printf("[%s]\n", duplicado);
  free(duplicado);
}
