Daphne -- Windows task manager replacement
Copyright (C) 2005,2014  Leandro H. Fernández

http://www.drk.com.ar/daphne.php

Buenos Aires, Argentina

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

NOTE: You will find the full license terms in COPYING.txt file.

Daphne anonymous statistical-data collection module collects Daphne usage-data 
and sends it to the open statistical database on-line: 
http://www.drk.com.ar/daphne-open-statistics-report.php

Daphne will under no circumstances collect personal data or information about
other software installed on the computer. You can read more about this: 
http://www.drk.com.ar/daphne-anonymous-statistics.php

By installing and/or using Daphne you agree to this anonymous usage-data
collection.
