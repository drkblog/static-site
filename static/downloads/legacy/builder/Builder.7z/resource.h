//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Spoofer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SPOOFER_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_URL                         104
#define IDR_MAINFRAME                   128
#define IDD_PROTOINFO                   129
#define IDD_RESOLVER                    130
#define IDD_RDWINDOW                    131
#define IDD_HELP                        132
#define IDB_LOGO                        134
#define IDB_DRKLOGO                     135
#define IDC_CREATE                      1000
#define IDC_PORT                        1001
#define IDC_TCP                         1002
#define IDC_UDP                         1003
#define IDC_IPADDR                      1004
#define IDC_DESROY                      1006
#define IDC_SBUFFER                     1007
#define IDC_SEND                        1008
#define IDC_RBUFFER                     1009
#define IDC_NOROUTE                     1010
#define IDC_OOB                         1011
#define IDC_RIPADDR                     1012
#define IDC_RPORT                       1013
#define IDC_CONNECT                     1014
#define IDC_BLOCK                       1015
#define IDC_ACCEPT                      1016
#define IDC_RCLR                        1017
#define IDC_SCLR                        1018
#define IDC_PACKETS                     1019
#define IDC_BYTES                       1020
#define IDC_LAST                        1021
#define IDC_WEB                         1022
#define IDC_ABOUT                       1023
#define IDC_KEEPALIVE                   1024
#define IDC_NODELAY                     1025
#define IDC_NETSTAT                     1026
#define IDC_INFO                        1027
#define IDC_NAME                        1028
#define IDC_RESOLVE                     1029
#define IDC_RESULT                      1030
#define IDC_DNSRES                      1031
#define IDC_RDETAIL                     1033
#define IDC_SCREEN                      1034
#define IDC_HELPB                       1035
#define IDC_RICHSCREEN                  1036
#define IDC_HELPSCREEN                  1037
#define IDC_SWITCH                      1038
#define IDC_SWHELP                      1039
#define IDC_BIND                        1040
#define IDC_DEBUG                       1041
#define IDC_PARSE                       1042
#define IDC_APPEND                      1043
#define IDC_BOUNDARIES                  1044
#define IDC_BCAST                       1045
#define IDC_CHECK2                      1046
#define IDC_REUSE                       1046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
