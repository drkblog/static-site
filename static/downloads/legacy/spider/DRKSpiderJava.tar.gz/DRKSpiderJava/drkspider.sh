#!/bin/bash
javaw -version 2> /dev/null
if [ $? == 0 ]; then
  javaw -jar drkspiderjava.jar
else
  java -version 2> /dev/null
  if [ $? == 0 ]; then
    java -jar drkspiderjava.jar
  else
    echo "FATAL: Java Runtime is not installed or JRE executable directory isn't in PATH"
  fi
fi

