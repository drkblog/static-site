DRKSpiderJava -- Website crawler and link checker
Copyright (C) 2009,2014  Leandro Fern�ndez
Buenos Aires, Argentina

RUN
---

For running DRKSpiderJava on Windows, Linux or Mac graphical
environment try first:

* Double click on drkspiderjava.jar

If that doesn't work:

Windows

* Double click on drkspider.cmd

Linux or Mac

1. Be sure drkspider.sh has execution permission
2. Double click on drkspider.sh


ABOUT
-----

Visit http://www.drk.com.ar/spider.php


LICENSE
-------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


NOTE: You will find the full license terms in COPYING.txt file.
